import React, { useState } from 'react'
import { waLink, WA_MESSAGES } from '../constants'

export default function FloatingWhatsApp() {
  const [pulse, setPulse] = useState(true)

  return (
    <a
      href={waLink(WA_MESSAGES.inquiry)}
      target="_blank"
      rel="noopener noreferrer"
      onMouseEnter={() => setPulse(false)}
      onMouseLeave={() => setPulse(true)}
      className="fixed bottom-6 right-5 z-50 group flex items-center gap-3"
      aria-label="Chat on WhatsApp"
    >
      {/* Tooltip label */}
      <span className="hidden md:block opacity-0 group-hover:opacity-100 transition-opacity duration-300 bg-brand-dark text-white font-body text-xs tracking-wide px-3 py-2 whitespace-nowrap shadow-lg">
        Chat with us
      </span>

      {/* Button */}
      <div className="relative">
        {/* Pulse ring */}
        {pulse && (
          <span className="absolute inset-0 rounded-full animate-ping bg-[#25D366] opacity-30" />
        )}
        <div className="relative w-14 h-14 bg-[#25D366] rounded-full flex items-center justify-center shadow-xl hover:scale-110 transition-transform duration-300">
          <svg width="26" height="26" viewBox="0 0 24 24" fill="white">
            <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347z"/>
            <path d="M12 0C5.373 0 0 5.373 0 12c0 2.126.553 4.12 1.524 5.854L0 24l6.335-1.504A11.94 11.94 0 0012 24c6.627 0 12-5.373 12-12S18.627 0 12 0zm0 21.818a9.818 9.818 0 01-5.016-1.376l-.36-.215-3.73.885.935-3.63-.234-.373A9.818 9.818 0 112 12 9.818 9.818 0 0112 21.818z"/>
          </svg>
        </div>
      </div>
    </a>
  )
}
